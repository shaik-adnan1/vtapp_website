const Events = () => {
  return;
};

export default Events;
