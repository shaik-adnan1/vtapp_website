import './home.route.css'

const Home = () => {
    return(
        <div className="section home_section">

        </div>
    );
}

export default Home;